@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title ORM Recommendation Engine - Setup

echo ==========================================================
echo   ORM Recommendation Engine - One-time Setup
echo ==========================================================
echo.

REM ---------- Step 1: check files ----------
echo [1/4] Checking project files...
set MISSING=0
for %%F in (recommendation_engine.py recommendation_tab.py pages\Recommendations.py) do (
    if not exist "%%F" (
        echo     MISSING: %%F
        set MISSING=1
    )
)
if "!MISSING!"=="1" (
    echo.
    echo     Please keep all files from the zip together in this folder.
    pause
    exit /b 1
)
if exist "orm_app.py" (
    echo     Found orm_app.py - Recommendations will appear as a sidebar page.
) else (
    echo     NOTE: orm_app.py not found in this folder.
    echo     Copy this folder's contents next to orm_app.py to combine them.
    echo     For now, the Recommendations page will run on its own.
)
echo.

REM ---------- Step 2: Python + virtual environment ----------
echo [2/4] Setting up Python virtual environment...
set PY=
where python >nul 2>nul && set PY=python
if not defined PY ( where py >nul 2>nul && set PY=py )
if not defined PY (
    echo     Python was not found. Install it from https://www.python.org/downloads/
    echo     and tick "Add Python to PATH" during installation, then run setup.bat again.
    pause
    exit /b 1
)
if not exist "venv\Scripts\activate.bat" (
    %PY% -m venv venv
    if errorlevel 1 ( echo     Could not create venv. & pause & exit /b 1 )
)
call venv\Scripts\activate.bat
echo     Installing packages - this can take a few minutes...
python -m pip install --upgrade pip -q
python -m pip install streamlit pandas numpy plotly matplotlib groq openpyxl -q
if errorlevel 1 ( echo     Package installation failed. Check your internet connection. & pause & exit /b 1 )
echo     Packages installed.
echo.

REM ---------- Step 3: Groq key + dataset ----------
echo [3/4] Configuration
if not exist ".streamlit" mkdir ".streamlit"
set WRITE=Y
if exist ".streamlit\secrets.toml" (
    set /p WRITE="    secrets.toml already exists. Overwrite it? [Y/N]: "
)
if /i "!WRITE!"=="Y" (
    echo.
    set KEY=
    set /p KEY="    Paste your Groq API key - or press Enter to skip: "
    echo.
    echo     Data files found in this folder:
    dir /b *.csv *.xlsx *.xls 2>nul
    echo.
    set DATA=
    set /p DATA="    Type the classified reviews file name - or press Enter to upload later in the app: "
    > ".streamlit\secrets.toml" echo GROQ_API_KEY = '!KEY!'
    >> ".streamlit\secrets.toml" echo DATA_FILE = '!DATA!'
    echo     Saved to .streamlit\secrets.toml
)
echo.

REM ---------- Step 4: Recommendations page ----------
echo [4/4] Recommendations page is installed at pages\Recommendations.py
echo     No changes to orm_app.py are needed.
echo.
echo ==========================================================
echo   Setup complete. From now on, just double-click run.bat
echo ==========================================================
echo.
set LAUNCH=Y
set /p LAUNCH="Launch the app now? [Y/N]: "
if /i "!LAUNCH!"=="Y" call run.bat
endlocal
