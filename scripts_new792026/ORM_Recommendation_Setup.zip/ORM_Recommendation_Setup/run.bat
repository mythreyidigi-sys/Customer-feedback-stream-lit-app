@echo off
cd /d "%~dp0"
if not exist "venv\Scripts\activate.bat" (
    echo Please run setup.bat first.
    pause
    exit /b 1
)
call venv\Scripts\activate.bat
if exist "orm_app.py" (
    python -m streamlit run orm_app.py
) else (
    python -m streamlit run pages\Recommendations.py
)
pause
