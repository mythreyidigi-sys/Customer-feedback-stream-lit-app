ORM Recommendation Engine - Quick Start
=======================================
1. Copy ALL files and the "pages" folder into the same folder as your orm_app.py
   and your classified reviews file (CSV/Excel).
2. Double-click setup.bat (first time only). It will:
     - check the files
     - create a Python virtual environment and install packages
     - ask for your Groq API key and dataset file name
     - add the Recommendations page (no edits to orm_app.py)
3. After that, double-click run.bat whenever you want to open the app.
   The app opens at http://localhost:8501 - look for "Recommendations" in the sidebar.

Mac users: run  bash setup_mac.sh  in the Terminal instead.
To change your key or dataset later, edit .streamlit\secrets.toml in Notepad/VS Code.
