#!/bin/bash
# Mac/Linux version of setup.bat. Run with:  bash setup_mac.sh
cd "$(dirname "$0")"
echo "[1/4] Checking files..."
for f in recommendation_engine.py recommendation_tab.py pages/Recommendations.py; do
  [ -f "$f" ] || { echo "MISSING: $f"; exit 1; }
done
echo "[2/4] Creating virtual environment and installing packages..."
[ -d venv ] || python3 -m venv venv
source venv/bin/activate
pip install -q --upgrade pip
pip install -q streamlit pandas numpy plotly matplotlib groq openpyxl
echo "[3/4] Configuration"
mkdir -p .streamlit
read -p "Groq API key (Enter to skip): " KEY
ls *.csv *.xlsx *.xls 2>/dev/null
read -p "Classified reviews file name (Enter to upload later): " DATA
printf "GROQ_API_KEY = '%s'\nDATA_FILE = '%s'\n" "$KEY" "$DATA" > .streamlit/secrets.toml
echo "[4/4] Done. Launching..."
if [ -f orm_app.py ]; then streamlit run orm_app.py; else streamlit run pages/Recommendations.py; fi
