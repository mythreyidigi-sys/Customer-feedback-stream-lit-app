"""
Recommendations page - appears automatically in the sidebar of orm_app.py.
No changes to orm_app.py are needed.
"""
import os
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from recommendation_tab import render_recommendation_tab  # noqa: E402

# Groq key from .streamlit/secrets.toml (optional)
try:
    if "GROQ_API_KEY" in st.secrets and st.secrets["GROQ_API_KEY"]:
        os.environ["GROQ_API_KEY"] = st.secrets["GROQ_API_KEY"]
except Exception:
    pass

CHAIN_CANDIDATES = ["restaurant", "restaurant_chain", "chain", "Restaurant"]
ISSUE_CANDIDATES = ["issue_cluster", "issue_label", "issue", "issue_category", "Issue"]
DATE_CANDIDATES = ["review_date", "date", "Date", "published_at"]


def pick(cols, candidates):
    for c in candidates:
        if c in cols:
            return c
    return None


@st.cache_data
def load(path_or_file, name):
    if name.lower().endswith((".xlsx", ".xls")):
        return pd.read_excel(path_or_file)
    return pd.read_csv(path_or_file)


df = None
data_file = ""
try:
    data_file = st.secrets.get("DATA_FILE", "")
except Exception:
    pass

if data_file and (ROOT / data_file).exists():
    df = load(ROOT / data_file, data_file)
else:
    st.info("Dataset not found automatically. Upload your classified reviews file.")
    up = st.file_uploader("Classified reviews (CSV or Excel)", type=["csv", "xlsx", "xls"])
    if up is not None:
        df = load(up, up.name)

if df is None:
    st.stop()

chain_col = pick(df.columns, CHAIN_CANDIDATES)
issue_col = pick(df.columns, ISSUE_CANDIDATES)
date_col = pick(df.columns, DATE_CANDIDATES)

if chain_col is None or issue_col is None:
    st.warning("Couldn't detect the restaurant or issue column. Please choose them.")
    chain_col = st.selectbox("Restaurant column", df.columns)
    issue_col = st.selectbox("Issue category column", df.columns)

render_recommendation_tab(df, chain_col=chain_col, issue_col=issue_col, date_col=date_col)
